import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { MDBBootstrapModule } from 'angular-bootstrap-md';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {AxisComponentsAllModule} from 'axis-components/components/components.module';
import { UserlistComponent } from './userlist/userlist.component';
import { AlbumComponent } from './album/album.component';
import { AlbumlistComponent } from './albumlist/albumlist.component';
import { SlideshowComponent } from './slideshow/slideshow.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';



@NgModule({
  declarations: [
    AppComponent,
    UserlistComponent,
    AlbumComponent,
    AlbumlistComponent,
    SlideshowComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AxisComponentsAllModule,
    BrowserAnimationsModule,
    MDBBootstrapModule.forRoot(),
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
