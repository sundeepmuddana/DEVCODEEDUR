import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable()
export class AlbumService {
  public userId:any;
  public AlbumId:any;
  public usersUrl = 'https://jsonplaceholder.typicode.com/users';
  public albumsurl = 'https://jsonplaceholder.typicode.com/albums';
  public photosurl='https://jsonplaceholder.typicode.com/photos';
  constructor(private http: HttpClient) {
    console.log('******', this.usersUrl);
  }
  getusers(): Observable<any> {
    return (this.http.get(this.usersUrl).pipe(map((res: Response) => {
      return res;
    })
    )
    );
  } 
  getPhotosbyAlbumid(AlbumId: number) {
    console.log('Photos', this.photosurl + "?albumId=" + AlbumId)
    return (this.http.get(this.photosurl + "?albumId=" + AlbumId).pipe(map((result: Response) => {
      return result;
    })));
  }
 
  getUsersAlbums(userId: number) {
    console.log('Albums', this.albumsurl + "?userId=" + userId)
    return (this.http.get(this.albumsurl + "?userId=" + userId).pipe(map((result: Response) => {
      return result;
    })));
  }

  getPhotosbySlideid(albumIds:any) {
    let albumIdsArray = albumIds.split(',');
    let queryString = '';
    if(albumIdsArray){
      for(let i=0; i<albumIdsArray.length;i++){
        if(i==0){
          queryString += "albumId="+albumIdsArray[i];
        }else{
          queryString += "&albumId="+albumIdsArray[i];
        }
        
      }
    }
    console.log('Photos', this.photosurl + "?"+queryString)
    return (this.http.get(this.photosurl + "?"+queryString).pipe(map((result: Response) => {
      return result;
    })));
  }

}
