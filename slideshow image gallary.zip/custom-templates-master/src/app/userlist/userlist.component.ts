import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlbumService } from '../services/album.service';


@Component({
  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.scss']

})
export class UserlistComponent implements OnInit {
  public Users : any;
  constructor(private albumService: AlbumService, private router: Router) {
  }

  ngOnInit() {
    this.albumService.getusers().subscribe(result => {
      this.Users = result;
      console.log(result)
    })
  }

  openalbums(userId) {
    this.router.navigate(['/album/', userId]);
  }
}
