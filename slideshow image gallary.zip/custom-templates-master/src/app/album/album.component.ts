import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AlbumService } from '../services/album.service';

@Component({
  selector: 'app-album',
  templateUrl: './album.component.html',
  styleUrls: ['./album.component.scss']
})
export class AlbumComponent implements OnInit {
  public Albumlist : any; 
  public userId : any;  
  public mutlipleId = []
  constructor(private albumService: AlbumService, private router: Router, private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.userId = this.activatedRoute.snapshot.params.userId;
    console.log('>>>>>> ngOnInit<<<<<<<<<' + this.userId);
    this.albumService.getUsersAlbums(this.userId).subscribe(result => {
      this.Albumlist = result;
    })
  }

  OpenPhotos(albumId: any) {
    this.router.navigate(['/albumlist/', albumId]);
  }
  Openslideshow(albumId: any) {
    this.router.navigate(['/slideshow/', albumId]);
  }
  select(event : any, alb: any) {
    if (event.length == 0) {
      if (this.mutlipleId.length >0) {
        let albumIndex = this.mutlipleId.indexOf(alb.id);
        this.mutlipleId.splice(albumIndex,1)
      }
    } else {
      this.mutlipleId.push(alb.id)
    }

  }
  Openslide() {
    if (this.mutlipleId.length != 0) {
      console.log('>>>id<<<', this.mutlipleId);
      let mutlipleIds = this.mutlipleId.join(',');
      this.router.navigate(['/slideshow/', mutlipleIds])
    }
  }
}

