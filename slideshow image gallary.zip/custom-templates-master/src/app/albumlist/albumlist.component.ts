import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AlbumService } from '../services/album.service';

@Component({
  selector: 'app-albumlist',
  templateUrl: './albumlist.component.html',
  styleUrls: ['./albumlist.component.scss']
})
export class AlbumlistComponent implements OnInit {
  public Photolist :any;  
  public albumIds :any;
 

  constructor(private albumService: AlbumService, private router: Router, private activatedRoute: ActivatedRoute) { }
  ngOnInit() {
    this.albumIds = this.activatedRoute.snapshot.params.albumId;
    this.albumService.getPhotosbyAlbumid(this.albumIds).subscribe(result => {
      this.Photolist = result;
    })
  }

}