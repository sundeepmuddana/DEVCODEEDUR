import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AlbumService } from '../services/album.service';



@Component({
  selector: 'app-slideshow',
  templateUrl: './slideshow.component.html',
  styleUrls: ['./slideshow.component.scss']
})
export class SlideshowComponent implements OnInit {
  public Photolist: any;
  public albumIds: any;
  constructor(private albumService: AlbumService, private router: Router, private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.albumIds = this.activatedRoute.snapshot.params.albumId;
    this.albumService.getPhotosbySlideid(this.albumIds).subscribe(result => {
      this.Photolist = result;
      let albumIdsArray = this.albumIds.split(',').map(function (item) {
        return parseInt(item, 10);
      });
      let array = []
      let lastAlbumArray = [];
      for (let i = 0; i < this.Photolist.length; i++) {
        for (let j = 0; j < albumIdsArray.length; j++) {
          let albumId = albumIdsArray[j];
          if (this.Photolist[i].albumId == albumId) {
            if (lastAlbumArray.indexOf(albumId) == -1) {
              array.push(this.Photolist[i])
              this.Photolist.splice(i, 1);
              lastAlbumArray.push(albumId);
              if (JSON.stringify(albumIdsArray) == JSON.stringify(lastAlbumArray)) {
                lastAlbumArray = [];
              }
              i = 0;
            }
          }
        }
      }
      this.Photolist = array;
    })
  }

}