export const environment = {
  hmr : false,
  production: true
};
