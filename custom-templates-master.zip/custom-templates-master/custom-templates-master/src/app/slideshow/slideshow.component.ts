import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AlbumService } from '../album.service';


@Component({
  selector: 'app-slideshow',
  templateUrl: './slideshow.component.html',
  styleUrls: ['./slideshow.component.scss']
})
export class SlideshowComponent implements OnInit {
  public Photolist;
  public Albumlist = [];
  public albumIds;
  imageWidth = 50;
  constructor(private albumService: AlbumService, private router: Router, private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    console.log('>>>>>', this.albumIds, '<<<<<<<<<<')
    this.albumIds = this.activatedRoute.snapshot.params.albumId;
    debugger
    this.albumService.getPhotosbySlideid(this.albumIds,this.albumIds).subscribe(result => {
      this.Photolist = result;
      console.log(this.Photolist)      
  })

}
}