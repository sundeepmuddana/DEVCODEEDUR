import { NgModule } from '@angular/core';
import { Routes, RouterModule, } from '@angular/router';
import { UserlistComponent } from './userlist/userlist.component';
import { AlbumComponent } from './album/album.component';
import { AlbumlistComponent } from './albumlist/albumlist.component';
import { AlbumService } from './album.service';
import { SlideshowComponent } from './slideshow/slideshow.component';


const routes: Routes = [
 
  {path: 'userlist',component: UserlistComponent},
  {path: 'album/:userId',component: AlbumComponent },
  {path : 'albumlist/:albumId' , component : AlbumlistComponent},  
  {path : 'slideshow/:albumId' , component : SlideshowComponent},
  {path: 'home',component: UserlistComponent},
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers:[AlbumService]
})
export class AppRoutingModule { }
