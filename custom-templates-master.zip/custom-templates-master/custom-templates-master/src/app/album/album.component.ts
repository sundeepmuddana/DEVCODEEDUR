import { Component, OnInit } from '@angular/core';
import { AlbumService } from '../album.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-album',
  templateUrl: './album.component.html',
  styleUrls: ['./album.component.scss']
})
export class AlbumComponent implements OnInit {
  Albumlist;
  public list = []
  public i;
  public userId;
  public Photolist;
  public albumId; 
  public albumIds; 
  public checkId;
  constructor(private albumService: AlbumService, private router: Router, private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.userId = this.activatedRoute.snapshot.params.userId;    
    console.log('>>>>>> ngOnInit<<<<<<<<<' + this.userId);
    this.albumService.getUsersAlbums(this.userId).subscribe(result => {
      this.Albumlist = result;
    })    
  }
 
  OpenPhotos(albumId) {
    this.router.navigate(['/albumlist/',albumId]); 
  }
  Openslideshow(albumId){
    this.router.navigate(['/slideshow/',albumId]);
  }
  select(event){
    console.log('>>>even<<<',event);
    this.checkId = event[0].value.id;
    console.log('>>>id<<<',event);    
  }
  Openslide(){    
    console.log('>>>id<<<',this.checkId);
     this.router.navigate(['/slideshow/',this.checkId])
  }
}

