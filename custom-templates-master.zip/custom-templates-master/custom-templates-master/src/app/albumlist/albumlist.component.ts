import { Component, OnInit } from '@angular/core';
import { AlbumService } from '../album.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-albumlist',
  templateUrl: './albumlist.component.html',
  styleUrls: ['./albumlist.component.scss']
})
export class AlbumlistComponent implements OnInit {
  public Photolist;  
  public albumIds;
  imageWidth = 50;

  constructor(private albumService: AlbumService, private router: Router, private activatedRoute: ActivatedRoute) { }
  ngOnInit() {
    // console.log('>>>>>> ngOnInit<<<<<<<<<'+ this.albumId);
    // this.albumId = this.activatedRoute.snapshot.params.albumId;
    // this.albumService.getPhotosbyAlbum().subscribe(result => {
    //   this.Photolist = result;
    //   console.log('///****//',result);
    // })
    // console.log('>>>>>>' + this.albumId);
    this.albumIds = this.activatedRoute.snapshot.params.albumId;
    this.albumService.getPhotosbyAlbumid(this.albumIds).subscribe(result => {
      this.Photolist = result;
    })
  }

}