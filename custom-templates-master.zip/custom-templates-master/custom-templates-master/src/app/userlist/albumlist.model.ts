export interface IAlbums {
    id: number;
    userId:number;
    title:string;
}