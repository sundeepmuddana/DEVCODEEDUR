import { Component, OnInit } from '@angular/core';
import { AlbumService } from '../album.service';
import { Router } from '@angular/router';
import { IUsers } from './userlist.model';
import { IAlbums } from './albumlist.model';

@Component({
  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.scss']

})
export class UserlistComponent implements OnInit {
  Users: IUsers[];
  Albumlist: IAlbums[];
  public list = []
  public kind:any = "info";
  public closeAlert(): void {
}

  constructor(private albumService: AlbumService, private router: Router) {
  }

  ngOnInit() {
    console.log('>>>>>> ngOnInit<<<<<<<<<');
    this.albumService.getusers().subscribe(result => {
      this.Users = result;
      console.log(result)

    })

  }
  alertChange(type:string) {
    this.kind = type;
  }
  openalbums(userId) {
    this.router.navigate(['/album/',userId]);   
  }
}
