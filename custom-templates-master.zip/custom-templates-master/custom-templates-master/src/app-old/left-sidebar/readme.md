* Please import HTML and TS to your project where you need to add left sidebar in your internal project.
