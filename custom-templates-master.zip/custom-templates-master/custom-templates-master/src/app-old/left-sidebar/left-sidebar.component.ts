import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-left-sidebar',
  templateUrl: './left-sidebar.component.html'
})
export class LeftSidebarComponent implements OnInit {

  /* properties */
  leftSidebarClosed: boolean = false;
  sectionHighlighted;

  constructor() { }

  ngOnInit() { }
}
