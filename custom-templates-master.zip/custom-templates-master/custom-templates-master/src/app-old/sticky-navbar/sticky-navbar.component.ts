import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sticky-navbar',
  templateUrl: './sticky-navbar.component.html'
})
export class StickyNavbarComponent implements OnInit {

  userName: string = 'User Name';

  constructor(
  ) { }

  /* lifecycle hooks */
  ngOnInit() {
  }

}
