/**
 * This shared module contains all the ui-generator modules.
 * Follow below steps to understand and use these modules:
 * 1. AxisUiGeneratorAllModule contains all AUG modules including core, form, components, charts and abc modules. If you want to use all, just uncomment this.
 * 2. You can comment/uncomment the modules whichever you want to use in your project.
 * 3. AxisUiGeneratorCoreModule and AxisUiGeneratorFormModule are mandatory modules, so uncomment them if you are not using AxisUiGeneratorAllModule.
 * 4. To add axis-ui-generator dependency(8.x) and its peer dependencies in your project, Use axis-cli command -  axis add axis-ui-generator
 * 6. import this module in your app.module.ts to use AUG features.
 */

import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

// AXIS UI GENERATOR
// import { AxisUiGeneratorAllModule } from 'axis-ui-generator/axis-ui-generator-all.module';
// import { AxisUiGeneratorCoreModule } from 'axis-ui-generator/axis-ui-generator-core.module';
// import { AxisUiGeneratorFormModule } from 'axis-ui-generator/axis-ui-generator-form.module';
// import { AxisUiGeneratorComponentsModule } from 'axis-ui-generator/axis-ui-generator-components.module';
// import { AxisUiGeneratorChartsModule } from 'axis-ui-generator/axis-ui-generator-charts.module';
// import { AxisUiGeneratorAbcsModule } from 'axis-ui-generator/axis-ui-generator-abcs.module';

const AUG_MODULES = [

  CommonModule,

  // >> UI GENERTATOR
  // AxisUiGeneratorAllModule,  // (ALL)
  // AxisUiGeneratorCoreModule,
  // AxisUiGeneratorFormModule,
  // AxisUiGeneratorComponentsModule,  // (ALL COMPONENTS)
  // AxisUiGeneratorChartsModule,  // (ALL CHARTS)
  // AxisUiGeneratorAbcsModule  // (ALL ABC's)
];

// AUG SHARED MODULE
@NgModule({
  imports: [...AUG_MODULES],
  declarations: [],
  exports: [...AUG_MODULES]
})
export class AxisSharedAugModule { }
