/**
 * This shared list contains all the individual AUG Control modules for axis-components, axis-charts and axis-abc components.
 * If you want to use few individual AUG components or charts or any of the abc component, then you can comment/uncomment the imports, 
 * and AUG_COMPONENT_ARRAY content whichever you want to use in your project.
 * If you are using all components or all charts or all abc components, then follow steps in axis-shared-aug.module.ts
 * 
 */

// List of all AXIS-COMPONENTS AUG CONTROLS
// import { CaptchaControlModule } from 'axis-ui-generator/form/captcha-control/captcha-control.module';
// import { CarouselControlModule } from 'axis-ui-generator/components/carousel-control/carousel-control.module';
// import { CheckboxControlModule } from 'axis-ui-generator/form/checkbox-control/checkbox-control.module';
// import { CheckboxGroupControlModule } from 'axis-ui-generator/form/checkbox-group-control/checkbox-group-control.module';
// import { ComboboxControlModule } from 'axis-ui-generator/form/combobox-control/combobox-control.module';
// import { CountdownControlModule } from 'axis-ui-generator/form/countdown-control/countdown-control.module';
// import { DatepickerControlModule } from 'axis-ui-generator/form/datepicker-control/datepicker-control.module';
// import { DaterangeControlModule } from 'axis-ui-generator/form/daterange-control/daterange-control.module';
// import { DobControlModule } from 'axis-ui-generator/form/dob-control/dob-control.module';
// import { DropdownControlModule } from 'axis-ui-generator/form/dropdown-control/dropdown-control.module';
// import { EditorControlModule } from 'axis-ui-generator/form/editor-control/editor-control.module';
// import { FileuploadControlModule } from 'axis-ui-generator/form/fileupload-control/fileupload-control.module';
// import { RadioControlModule } from 'axis-ui-generator/form/radio-control/radio-control.module';
// import { SliderControlModule } from 'axis-ui-generator/form/slider-control/slider-control.module';
// import { TextControlModule } from 'axis-ui-generator/form/text-control/text-control.module';
// import { TextareaControlModule } from 'axis-ui-generator/form/textarea-control/textarea-control.module';
// import { TimepickerControlModule } from 'axis-ui-generator/form/timepicker-control/timepicker-control.module';
// import { ToggleControlModule } from 'axis-ui-generator/form/toggle-control/toggle-control.module';
// import { TypeaheadControlModule } from 'axis-ui-generator/form/typeahead-control/typeahead-control.module';

// // COMPONENTS CONTROLS for AUG
// import { AccordionControlModule } from 'axis-ui-generator/components/accordion-control/accordion-control.module';
// import { AlertControlModule } from 'axis-ui-generator/components/alert-control/alert-control.module';
// import { AqiControlModule } from 'axis-ui-generator/components/aqi-control/aqi-control.module';
// import { ButtonControlModule } from 'axis-ui-generator/components/button-control/button-control.module';
// import { ButtonGroupControlModule } from 'axis-ui-generator/components/button-group-control/button-group-control.module';
// import { ButtonRowControlModule } from 'axis-ui-generator/components/button-row-control/button-row-control.module';
// import { DualListControlModule } from 'axis-ui-generator/components/dual-list-control/dual-list-control.module';
// import { IconControlModule } from 'axis-ui-generator/components/icon-control/icon-control.module';
// import { ListControlModule } from 'axis-ui-generator/components/list-control/list-control.module';
// import { ModalControlModule } from 'axis-ui-generator/components/modal-control/modal-control.module';
// import { NavbarControlModule } from 'axis-ui-generator/components/navbar-control/navbar-control.module';
// import { ProgressBarControlModule } from 'axis-ui-generator/components/progress-bar-control/progress-bar-control.module';
// import { TabControlModule } from 'axis-ui-generator/components/tab-control/tab-control.module';
// import { TooltipControlModule } from 'axis-ui-generator/components/tooltip-control/tooltip-control.module';
// import { TruncateControlModule } from 'axis-ui-generator/components/truncate-control/truncate-control.module';


// // List of all AXIS-CHARTS AUG CONTROLS
// import { AreaPlusLineChartControlModule } from 'axis-ui-generator/charts/area-plus-line-chart-control/area-plus-line-chart-control.module';
// import { BarPlusMultiLineChartControlModule } from 'axis-ui-generator/charts/bar-plus-multi-line-control/bar-plus-multi-line-control.module';
// import { BarPlusMultiLineGroupedChartControlModule } from 'axis-ui-generator/charts/bar-plus-multi-line-grouped-control/bar-plus-multi-line-grouped-control.module';
// import { BodymapChartControlModule } from 'axis-ui-generator/charts/bodymap-control/bodymap-control.module';
// import { DatamapsChartControlModule } from 'axis-ui-generator/charts/datamaps-control/datamaps-control.module';
// import { DonutChartControlModule } from 'axis-ui-generator/charts/donut-control/donut-control.module';
// import { HorizontalBarChartControlModule } from 'axis-ui-generator/charts/horizontal-bar-control/horizontal-bar-control.module';
// import { Nvd3ChartControlModule } from 'axis-ui-generator/charts/nvd3-control/nvd3-control.module';
// import { WordcloudChartControlModule } from 'axis-ui-generator/charts/wordcloud-control/wordcloud-control.module';


// // List of all AXIS-ABC AUG CONTROLS
// import { AbcPortalMenuControlModule } from 'axis-ui-generator/abc/abc-portal-menu-control/abc-portal-menu-control.module';
// import { AbcSearchAccountControlModule } from 'axis-ui-generator/abc/abc-search-account-control/abc-search-account-control.module';
// import { AbcSearchAddressControlModule } from 'axis-ui-generator/abc/abc-search-address-control/abc-search-address-control.module';


/**
 * List of all the AUG Controls
 */
export const AUG_COMPONENT_ARRAY = [

  // FORMS
  // CaptchaControlModule,
  // CarouselControlModule,
  // CheckboxControlModule,
  // CheckboxGroupControlModule,
  // ComboboxControlModule,
  // CountdownControlModule,
  // DatepickerControlModule,
  // DaterangeControlModule,
  // DobControlModule,
  // DropdownControlModule,
  // EditorControlModule,
  // FileuploadControlModule,
  // RadioControlModule,
  // SliderControlModule,
  // TextControlModule,
  // TextareaControlModule,
  // TimepickerControlModule,
  // ToggleControlModule,
  // TypeaheadControlModule,

  // // COMPONENTS
  // AccordionControlModule,
  // AlertControlModule,
  // AqiControlModule,
  // ButtonControlModule,
  // ButtonGroupControlModule,
  // ButtonRowControlModule,
  // DualListControlModule,
  // IconControlModule,
  // ListControlModule,
  // ModalControlModule,
  // NavbarControlModule,
  // ProgressBarControlModule,
  // TabControlModule,
  // TooltipControlModule,
  // TruncateControlModule,

  // //  CHARTS
  // AreaPlusLineChartControlModule,
  // BarPlusMultiLineChartControlModule,
  // BarPlusMultiLineGroupedChartControlModule,
  // BodymapChartControlModule,
  // DatamapsChartControlModule,
  // DonutChartControlModule,
  // HorizontalBarChartControlModule,
  // Nvd3ChartControlModule,
  // WordcloudChartControlModule,

  // // Business Components (ABC)
  // AbcPortalMenuControlModule,
  // AbcSearchAccountControlModule,
  // AbcSearchAddressControlModule
];


// Use this object to inject Custom components into Axis-UI-Generator
export const ComponentRegistry = {};
