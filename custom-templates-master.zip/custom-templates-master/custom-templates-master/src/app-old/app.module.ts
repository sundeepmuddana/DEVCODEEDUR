import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AxisSharedModule } from './_shared/axis-shared.module';
import {NavbarComponent} from './navbar/navbar.component';
import {LeftSidebarComponent} from './left-sidebar/left-sidebar.component';
import {RightSidebarComponent} from './right-sidebar/right-sidebar.component';
import {StickyNavbarComponent} from './sticky-navbar/sticky-navbar.component';
@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    LeftSidebarComponent,
    RightSidebarComponent,
    StickyNavbarComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AxisSharedModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
