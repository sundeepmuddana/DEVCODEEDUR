import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html'
})
export class NavbarComponent implements OnInit {

  /* properties */
  navPanel1: boolean = false;
  public navbarOpen: any;
  public innerPanel: any

  constructor() { }

  ngOnInit() { }
  clickOverlay() {
	this.navbarOpen = false;
  }
  toggleNavbar(): void {
    this.innerPanel = '';
    this.navbarOpen = !this.navbarOpen;
  }
}
