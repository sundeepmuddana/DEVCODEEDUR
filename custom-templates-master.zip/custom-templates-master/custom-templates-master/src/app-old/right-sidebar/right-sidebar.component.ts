import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-right-sidebar',
  templateUrl: './right-sidebar.component.html',
})
export class RightSidebarComponent implements OnInit {
  /* properties */
  rightSidebarClosed: Boolean = false;

  constructor() { }

  ngOnInit(): void {
  }

}
